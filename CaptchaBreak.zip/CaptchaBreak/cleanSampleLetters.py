import numpy as np
import cv2
from matplotlib import pyplot as plt
import os

directory = 'SampleLetters'
for filename in os.listdir(directory):
    if filename.endswith(".jpg"):
        im = cv2.imread(os.path.join(directory,filename))
        height, width = im.shape[:2]
        if height<50 and width<50:
            os.remove(os.path.join(directory,filename))
            print filename