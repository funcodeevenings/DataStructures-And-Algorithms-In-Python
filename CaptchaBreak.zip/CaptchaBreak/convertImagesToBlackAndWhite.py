import numpy as np
import cv2
from matplotlib import pyplot as plt
import os


directory = 'Test1'
directory_out = 'Train1'
for filename in os.listdir(directory):
    if os.path.isdir(os.path.join(directory,filename)):
        print filename
        directory1 = os.path.join(directory,filename)
        print directory1
        for fname in os.listdir(directory1):
            if fname.endswith(".jpg"):
                image = cv2.imread(os.path.join(directory1,fname))
                gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
                cv2.imwrite(os.path.join(directory1,fname),gray)
            