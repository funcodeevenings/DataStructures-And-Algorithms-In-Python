import pytesseract
from PIL import Image, ImageEnhance, ImageFilter
import os
#from ./pytesser import pytesser

def captcha_solver(img="1"):
	im = Image.open(img)
	im = im.convert("RGBA")
	newimdata = []
	datas = im.getdata()

	im = im.filter(ImageFilter.MedianFilter())
	enhancer = ImageEnhance.Contrast(im)
	brightness = ImageEnhance.Brightness(im)
	sharpness = ImageEnhance.Sharpness(im)
	im = brightness.enhance(2)
	im = enhancer.enhance(2)
	im = sharpness.enhance(2)
	#im = im.convert('1')

	pixels = list(im.getdata())
	width, height = im.size
	pixels = [pixels[i * width:(i + 1) * width] for i in xrange(height)]
	countb=0
	countw=0
	for i,row in enumerate(pixels):
		for j,col in enumerate(row):
			a,b,c,d = col
			if a<b+c:
				countw=countw+1
			else:
				countb=countb+1
			pixels[i][j] = neighbouhood_intensity(pixels,i,j,col,width,height)

	print countb,countw
	pixels_out = []
	for row in pixels:
		for tup in row:
			pixels_out.append(tup)
	image_out = Image.new(im.mode,im.size)
	image_out.putdata(pixels_out)
	filename = img.split('\\')[1].split('.')[0]+'.png'
	directory2='SampleBlack'
	final_path = os.path.join(directory2, filename)
#	print final_path
	image_out.save(final_path)
#	text = pytesseract.image_to_string(Image.open('temp_3.png'))
#	print text

	#im.save('temp2.jpg')

	#print(pytesseract.image_to_string(Image.open('input-black.gif')))

def neighbouhood_intensity(pixels,row,col,val,width,height):
	countw,countb=0,0
	if row-1>=0:
		if col-1>=0:
			if notRed(pixels[row-1][col-1]):
				countw=countw+1
			else:
				countb=countb+1
		if notRed(pixels[row-1][col]):
			countw=countw+1
		else:
			countb=countb+1
		if col+1<width:
			if notRed(pixels[row-1][col+1]):
				countw=countw+1
			else:
				countb=countb+1
		
	if col-1>=0:
		if notRed(pixels[row][col-1]):
			countw=countw+1
		else:
			countb=countb+1
	if notRed(pixels[row][col]):
		countw=countw+1
	else:
		countb=countb+1
	if col+1<width:
		if notRed(pixels[row][col+1]):
			countw=countw+1
		else:
			countb=countb+1

	if row+1<height:
		if col-1>=0:
			if notRed(pixels[row+1][col-1]):
				countw=countw+1
			else:
				countb=countb+1
		if notRed(pixels[row+1][col]):
			countw=countw+1
		else:
			countb=countb+1
		if col+1<width:
			if notRed(pixels[row+1][col+1]):
				countw=countw+1
			else:
				countb=countb+1

	if countb>=countw:
		return (0,0,0,255)
	else:
		return (255,255,255,255)

def notRed(pixel):
	a,b,c,d = pixel
	if a<(b+c):
		return True
	return False

directory='SampleRED'
for filename in os.listdir(directory):
    if filename.endswith(".jpg"):
		captcha_solver(os.path.join(directory, filename))