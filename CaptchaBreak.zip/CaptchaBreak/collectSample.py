import requests
import shutil
import os
import string
import random

url='https://ipindiaonline.gov.in/eregister/CaptchaGenerator/captcha.aspx?636756328598754045'
dirname = 'SampleRED'
for i in range(10,100):
    r = requests.get(url, stream=True)
    fileName=''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(4))
    fileName = fileName+'.jpg'
    if r.status_code == 200:
        with open(os.path.join(dirname,fileName), 'wb') as f:
            r.raw.decode_content = True
            shutil.copyfileobj(r.raw, f)
