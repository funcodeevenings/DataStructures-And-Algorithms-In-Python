import string
import os

directory = 'Validate1'
print directory

for alph in list(string.ascii_lowercase):
    dirname = directory+'/'+alph
    if not os.path.exists(dirname):
        os.mkdir(dirname)

for alph in list(string.ascii_uppercase):
    dirname = directory+'/cap'+alph
    if not os.path.exists(dirname):
        os.mkdir(dirname)

for num in range(10):
    dirname = directory+'/'+str(num)
    if not os.path.exists(dirname):
        os.mkdir(dirname)