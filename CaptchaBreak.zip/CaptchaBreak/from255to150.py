import numpy as np
import cv2
from matplotlib import pyplot as plt
import os



directory = 'Validate'
directory_out = 'Validate1'

for filename in os.listdir(directory):
    if os.path.isdir(os.path.join(directory,filename)):
        print filename
        directory1 = os.path.join(directory,filename)
        print directory1
        directory_out1 = os.path.join(directory_out,filename)
        for fname in os.listdir(directory1):
            if fname.endswith(".jpg"):
                img =cv2.imread(os.path.join(directory1,fname))
                crop_img = img[52:202, 52:202]
                cv2.imwrite(os.path.join(directory_out1,fname),crop_img)

    else:
        for fname in os.listdir(directory):
            if fname.endswith(".jpg"):
                img =cv2.imread(os.path.join(directory,fname))
                crop_img = img[52:202, 52:202]
                cv2.imwrite(os.path.join(directory_out,fname),crop_img)