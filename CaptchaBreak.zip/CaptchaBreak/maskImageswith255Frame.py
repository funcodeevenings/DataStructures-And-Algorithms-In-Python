import numpy as np
import cv2
from matplotlib import pyplot as plt
import os



directory = 'Validate'
directory_out = 'Validate1'

for filename in os.listdir(directory):
    if os.path.isdir(os.path.join(directory,filename)):
        print filename
        directory1 = os.path.join(directory,filename)
        print directory1
        directory_out1 = directory1
        for fname in os.listdir(directory1):
            if fname.endswith(".jpg"):
                img =cv2.imread(os.path.join(directory1,fname))
                height, width = img.shape[:2]
                vert = 255-height
                top = vert//2
                bottom=vert-top
                horiz = 255-width
                left=horiz//2
                right=horiz-left
                bordered_img = cv2.copyMakeBorder(img, top, bottom, left, right, cv2.BORDER_CONSTANT,value=(255,255,255))
                cv2.imwrite(os.path.join(directory_out1,fname),bordered_img)