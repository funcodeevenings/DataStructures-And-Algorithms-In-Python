import numpy as np
import cv2
from matplotlib import pyplot as plt
import os

directory = 'Test'
directory_out = 'Test1'
for filename in os.listdir(directory):
    im = cv2.imread(os.path.join(directory,filename))
    height, width = im.shape[:2]
    im = cv2.resize(im,(4*width, 4*height), interpolation = cv2.INTER_CUBIC)
    imgray = cv2.cvtColor(im, cv2.COLOR_BGR2GRAY)
    ret,thresh = cv2.threshold(imgray,127,255,0)
    image, contours, hierarchy = cv2.findContours(thresh,cv2.RETR_TREE,cv2.CHAIN_APPROX_SIMPLE)
    for i,cnt in enumerate(contours):
        if hierarchy[0][i][3]==0:
            rect = cv2.minAreaRect(cnt)
            box = cv2.boxPoints(rect)
            box = np.int0(box)
            img_box = im.copy()
            x,y,w,h = cv2.boundingRect(cnt)
            for j in range(x,x+w):
                for k in range(y,y+h):
                    if cv2.pointPolygonTest(box,(j,k), False) <=0:
                        cv2.circle(img_box,(j,k),1,(255,255,255),1)
            center = (int((x+x+w)/2), int((y+y+h)/2))
            size = (int(w),int(h))
            cropped = cv2.getRectSubPix(img_box, size, center)
            fname=filename.split('.')[-2]+str(i)+'.jpg'
            cv2.imwrite(os.path.join(directory_out,fname),cropped)

        