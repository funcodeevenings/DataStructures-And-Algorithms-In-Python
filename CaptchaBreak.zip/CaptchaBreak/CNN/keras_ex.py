import numpy as np
import keras
from keras import backend as K
from keras.models import Sequential
from keras.layers import Activation,Conv2D, MaxPooling2D, Dropout
from keras.layers.core import Dense, Flatten
from keras.optimizers import Adam
from keras.metrics import categorical_crossentropy
from keras.preprocessing.image import ImageDataGenerator
from matplotlib import pyplot as plt
from sklearn.metrics import confusion_matrix
import itertools

train_path = '../Train1'
valid_path = '../Validate1'
test_path = '../Test1'
train_batches = ImageDataGenerator().flow_from_directory(train_path,target_size=(150,150),color_mode="grayscale",class_mode="categorical",shuffle=True, batch_size=4)
valid_batches = ImageDataGenerator().flow_from_directory(valid_path,target_size=(150,150),color_mode="grayscale",class_mode="categorical",shuffle=True,batch_size=2)
test_batches = ImageDataGenerator().flow_from_directory(test_path,target_size=(150,150),color_mode="grayscale",class_mode=None,shuffle=True,batch_size=2)

imgs,labels = next(train_batches)

#Build and train CNN
model = Sequential()
model.add(Conv2D(62,(3,3), padding='same', activation='relu',input_shape=(150,150,1)))
model.add(Conv2D(62,(3,3),activation='relu'))
model.add(MaxPooling2D(pool_size=(2,2)))
model.add(Dropout(0.25))

model.add(Conv2D(62,(3,3), padding='same',activation='relu'))
model.add(Conv2D(62,(3,3),activation='relu'))
model.add(MaxPooling2D(pool_size=(2,2)))
model.add(Flatten())
model.add(Dropout(0.25))

model.add(Dense(512,activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(62, activation='softmax'))
#model.summary()
model.compile(loss='categorical_crossentropy',
 optimizer='adam',
 metrics=['accuracy'])
#traiin the model
model.fit_generator(train_batches, epochs=10,validation_data=valid_batches)
#save neural network structure
model_structure = model.to_json()
f = Path('model_structure.json')
f.write_text(model_structure)

#Save neural network's trained weights
model.sample_weights('model_weights.h5')